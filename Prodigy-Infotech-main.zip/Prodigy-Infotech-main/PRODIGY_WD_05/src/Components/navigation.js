function Navigation() { 
    return (
        <>
            <div className="currstat" id="currstat"></div>
            <div className="stat" id="stat"></div>
        </>
        
    )
}

export default Navigation;